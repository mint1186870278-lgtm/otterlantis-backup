import sqlite3
import json
import os
from pathlib import Path

DB_PATH = Path(__file__).parent / 'otter.db'
conn = None


def init_db():
    global conn
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tracking_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            event TEXT NOT NULL,
            payload TEXT,
            ts INTEGER NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS retention_submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT,
            wechat TEXT,
            lang TEXT NOT NULL,
            source TEXT NOT NULL,
            ts INTEGER NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('CREATE INDEX IF NOT EXISTS idx_tracking_session ON tracking_events(session_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_tracking_event ON tracking_events(event)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_retention_lang ON retention_submissions(lang)')

    conn.commit()
    print('Database initialized')


def insert_tracking_event(session_id, event, payload, ts):
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO tracking_events (session_id, event, payload, ts) VALUES (?, ?, ?, ?)',
        (session_id, event, json.dumps(payload), ts)
    )
    conn.commit()


def insert_retention_submission(data):
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO retention_submissions (email, wechat, lang, source, ts) VALUES (?, ?, ?, ?, ?)',
        (data.get('email'), data.get('wechat'), data['lang'], data['source'], data['ts'])
    )
    conn.commit()


def get_tracking_stats():
    cursor = conn.cursor()

    cursor.execute('SELECT COUNT(*) FROM tracking_events')
    total = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(DISTINCT session_id) FROM tracking_events')
    sessions = cursor.fetchone()[0]

    cursor.execute('SELECT event, COUNT(*) FROM tracking_events GROUP BY event')
    by_event = [{'event': row[0], 'count': row[1]} for row in cursor.fetchall()]

    return {'total': total, 'sessions': sessions, 'byEvent': by_event}


def get_retention_stats():
    cursor = conn.cursor()

    cursor.execute('SELECT COUNT(*) FROM retention_submissions')
    total = cursor.fetchone()[0]

    cursor.execute('SELECT lang, COUNT(*) FROM retention_submissions GROUP BY lang')
    by_lang = [{'lang': row[0], 'count': row[1]} for row in cursor.fetchall()]

    cursor.execute('SELECT id, email, wechat, lang, source, ts, created_at FROM retention_submissions ORDER BY created_at DESC LIMIT 10')
    recent = [
        {'id': row[0], 'email': row[1], 'wechat': row[2], 'lang': row[3], 'source': row[4], 'ts': row[5], 'created_at': row[6]}
        for row in cursor.fetchall()
    ]

    return {'total': total, 'byLang': by_lang, 'recent': recent}
